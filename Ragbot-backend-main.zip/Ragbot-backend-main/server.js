const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { OpenAI } = require("openai"); // use OpenAI SDK for HF

dotenv.config();

const app = express();

// Middlewares
app.use(
  cors({
    origin: ["https://rag-bot-peach.vercel.app", "http://localhost:5173"],
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(express.json());

app.get("/", (req, res) => res.send("Hugging Face Backend Running"));

// Initialize OpenAI-compatible client for HF
const client = new OpenAI({
  apiKey: process.env.HF_API_KEY,
  baseURL: "https://router.huggingface.co/v1", // HF OpenAI-compatible endpoint
});

app.post("/api/chat", async (req, res) => {
  const { message, model } = req.body;

  if (!message || !model) {
    return res.status(400).json({ error: "Message and model are required" });
  }

  try {
    const chatCompletion = await client.chat.completions.create({
      model, // e.g., "MiniMaxAI/MiniMax-M2.1:novita"
      messages: [
        {
          role: "user",
          content: message,
        },
      ],
    });

    const reply =
      chatCompletion.choices?.[0]?.message?.content || "No response from model";

    res.json({ reply });
  } catch (error) {
    console.error("HF Error:", error.response?.data || error.message);
    res.status(500).json({ error: "HF API error" });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
